# To Do
This web application is a simple application to manage a list of things to do.

Don't forget to give this repo a ⭐ if you like and want to appreciate my efforts

## Infrastructure

This applications consists of two parts:
  1. Frontend: Single Page Application built with: React and Material.
  2. Backend: REST API built with Node.js, Express, Redis and MongoDB.

## Features

![F](https://user-images.githubusercontent.com/63356649/127074968-f05f3470-bdd9-48d8-a56a-9b0e0ffca74e.JPG)

Don't forget to give this repo a ⭐ if you like and want to appreciate my efforts
